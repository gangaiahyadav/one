<?php 

$id = $_GET['id'];
$host = "localhost";
$user = "root";
$pwd  = "";
$db   = "mytest";
$con  = new mysqli($host,$user,$pwd,$db);
if(!$con){die('Database Connection Error:'.$con->errno.' - '.$con->error);}
$query = "select * from state where country_id = ".(int)$id." order by state_name";
$states = $con->query($query);
$results = array();
while($sta = $states->fetch_object()){
	$state = array();
	$state['id'] = $sta->state_id;
	$state['name'] = ucwords($sta->state_name);	
	$results[] = $state;
}
echo json_encode($results); die();
	
?>