<?php 
$host = "localhost";
$user = "root";
$pwd  = "";
$db   = "mytest";
$con  = new mysqli($host,$user,$pwd,$db);
if(!$con){die('Database Connection Error:'.$con->errno.' - '.$con->error);}
$user_id = $_GET['user_id'];
$dquery = "delete from user where user_id = ".$user_id;
if($con->query($dquery)){
	echo 'success';	
}else{echo 'error';}	
die();
?>