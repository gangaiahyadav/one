<!DOCTYPE html>
<html>
<head>
<title>User Data</title>
<script src="jquery.min.js" ></script>
<style type="text/css">
#user {
	width:270px;
	margin:auto;
	background-color:#f7f7f7;
	padding:40px;
}
input[type="text"], input[type="email"], label {
	display:block;
	margin-bottom:10px;
	width:100%;
	height:25px;
}
#state, #country {
	Width:100%;
	margin-bottom:10px;
	height:27px;
}
#buttons input[type="submit"], input[type="reset"] {
	display:block;
	width:45%;
	margin-right:5px;
	float:left;
	height:30px;
}
input[type="reset"] {
	background-color:#f77;
}
input[type="reset"]:hover {
	background-color:#f55;
}
input[type="submit"] {
	background-color:#7f7;
}
input[type="submit"]:hover {
	background-color:#5f5;
}
table {
	border-collapse:collapse;
	width:100%
}
table th {
	border:1px solid #000;
	width:100px;
	text-align:left;
	padding:15px;
	border-bottom:1px solid #000;
	background-color: #4CAF50;
	color: white;
}
td {
	vertical-align:bottom;
	height:50px;
	padding:15px;
	border-bottom:1px solid #000;
}
tr:hover {
	background-color: #f5f5f5;
}
tr:nth-child(even) {
background-color: #f2f2f2
}
</style>
</head>
<body>
<?php 
$host = "localhost";
$user = "root";
$pwd  = "";
$db   = "mytest";
$con  = new mysqli($host,$user,$pwd,$db);
if(!$con){die('Database Connection Error:'.$con->errno.' - '.$con->error);}
$cquery = "select * from country order by country_name";
$cresults = $con->query($cquery);
$countrys = $cresults->fetch_all();
?>
<div id="user" >
  <h2>User Registration</h2>
  <form name="userform" id="userform" action="javascript:void(0)">
    <label for="Name">Name</label>
    <input type="text" name="name" autocomplete="off" required id="name" >
    <label for="Email">Email</label>
    <input type="email" name="email" autocomplete="off" required id="email">
    <label for="Mobile" >Mobile</label>
    <input type="text" name="mobile" autocomplete="off" required id="mobile">
    <label for="Gender">Gender</label>
    <input type="radio" name="gender" checked  value="Male">
    Male
    <input type="radio" name="gender"  value="Female">
    Female
    <label for="Language">Languages</label>
    <input type="checkbox" name="language[]"   value="HTML">
    HTML
    <input type="checkbox" name="language[]"  checked value="PHP">
    PHP
    <label for="Country">Country</label>
    <select name="country" id="country" required>
      <option>- - Select Country - -</option>
      <?php foreach($countrys as $c){ ?>
      <option value="<?php echo $c[0] ?>" ><?php echo $c[1]; ?></option>
      <?php } ?>
    </select>
    <label for="State" >State</label>
    <select name="state" id="state" required>
      <option>- - Select State - -</option>
    </select>
    <div id="buttons">
      <input type="submit" name="submit" value="Submit">
      <input type="reset" name="reset" value="Reset">
    </div>
  </form>
</div>
<div id="userdata">
<h2>User Details</h2>
  <table>
    <thead>
      <tr>
        <th>S.No</th>
        <th>Name</th>
        <th>Email</th>
        <th>Mobile</th>
        <th>Gender</th>
        <th>Language</th>
        <th>Country</th>
        <th>State</th>
        <th>Delete</th>
      </tr>
    </thead>
    <tbody id="tabledata">
    </tbody>
  </table>
</div>

<script>
$(function(){	
	$("#country").change(function(){
			var id = $(this).val(); 
			$.ajax({
				url:'states.php',		
				method:'post',
				data:'id='+id,
				dataType:"json",
				success:function(data){ 
					var slen = data.length;
					var options = '<option value="">- - Select State - -</option>';
					for(var i = 0; i<slen;i++){
						options += '<option value="'+data[i].id+'">'+data[i].name+'</option>';						
					}
					$('#state').empty().append(options);
				},
				error:function(data){console.log(data.responceText);},
				complete:function(){}				
			});
	});
	$('#userform').submit(function(){
			var url = 'save.php';
			$.ajax({
				url:url,
				method:'post',
				data:$(this).serialize(),
				success:function(result){  
					result = result.trim();
					if(result == 'success'){
						alert('Successully registered with us');
						getData();						
					}else{
						alert('Registration Failed, Please Try Again');
					}				
				},
				error:function(data){},
				complete:function(){}			
			});	
	});
	
	getData();
	function getData(){
		$.ajax({
			url:'getdata.php',
			method:'post',
			dataType:'json',
			success:function(result){  
				var $users = '', sno =0,
				 dlen = result.length;
				if(dlen>0){							
					for(var i =0;i<dlen;i++){
						 sno = ++sno;
						$users += '<tr>';
						$users += '<td>'+sno+'<td>';		
						$users += '<td>'+result[i].name+'<td>';
						$users += '<td>'+result[i].email+'<td>';
						$users += '<td>'+result[i].mobile+'<td>';
						$users += '<td>'+result[i].gender+'<td>';
						$users += '<td>'+result[i].language+'<td>';
						$users += '<td>'+result[i].country+'<td>';
						$users += '<td>'+result[i].state+'<td>';
						$users += '<td><a class="delete" href="javascript:void(0)" index="'+result[i].id+'"  >delete</a><td>';
						$users += '</tr>';	
					}	
					$('#tabledata').html($users);
				}else{$('#tabledata').html('<tr><td colspan="9">No User Data Available, Please Add A user</td></tr>');}
			},
			error:function(result){
				alert(result.responceText);
			},
			complete:function(){}		
		});		
	}	
	$('.delete').live('click',function(){
		userid = $(this).attr('index');	
		if(confirm('Are you sure to delete record?')){
			$.ajax({
				url:'delete.php',
				method:'post',
				data:'user_id='+userid,
				success:function(result){ 
					if(result == 'success'){ alert('Record Successfully deleted');}else{alert('Record Not Deleted, Please Try Again');}
					 location.reload();
				},
				error:function(result){console.log(result.responceText);},
				complete:function(){},
			});
		}
	});
});
</script>
</body>
</html>
