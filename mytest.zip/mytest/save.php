<?php 
$host = "localhost";
$user = "root";
$pwd  = "";
$db   = "mytest";
$con  = new mysqli($host,$user,$pwd,$db);
if(!$con){die('Database Connection Error:'.$con->errno.' - '.$con->error);}
$name 		= ucwords($_GET['name']);
$email 		= $_GET['email'];
$mobile 	= $_GET['mobile'];
$gender		= $_GET['gender'];
$language 	= implode(',',$_GET['language']);	
$country	= $_GET['country'];
$state		= $_GET['state'];
$query 		= 'insert user (name,email,mobile,gender,language,country_id,state_id) values("'.$name.'","'.$email.'","'.$mobile.'","'.$gender.'","'.$language.'",'.$country.','.$state.')'; 
if($con->query($query)){
	echo'success';
}else{
	echo 'error';
}
die();
?>