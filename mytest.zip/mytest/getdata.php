<?php 
$host = "localhost";
$user = "root";
$pwd  = "";
$db   = "mytest";
$con  = new mysqli($host,$user,$pwd,$db);
if(!$con){die('Database Connection Error:'.$con->errno.' - '.$con->error);}
$dquery = "select u.*,c.country_name,s.state_name from user as u left join country as c on u.country_id = c.country_id left join state as s on u.state_id = s.state_id   WHERE 1 = 1 ORDER by u.name ,u.create_date";
$result = $con->query($dquery);
$users  = '';
while($data = $result->fetch_object()){
	$user = array();
	$user['id'] 		= $data->user_id;
	$user['name'] 		= $data->name;
	$user['mobile']		= $data->mobile;
	$user['email']		= $data->email;
	$user['gender']		= $data->gender;
	$user['language']	= $data->language;
	$user['country']	= $data->country_name;
	$user['state']		= $data->state_name;
	$users[]	= $user;
}	
echo json_encode($users);

die();
?>